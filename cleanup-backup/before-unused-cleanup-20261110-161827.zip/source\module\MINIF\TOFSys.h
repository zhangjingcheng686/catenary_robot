/* TOFSys.h */
#ifndef __TOFSYS_H__
#define __TOFSYS_H__

#include "main.h"
#include "uart_api.h"
#include <stdbool.h>

#define TOF_BUFF_SIZE     32      
#define TOF_TIMEOUT_MS    100     

/**
 * @brief TOF传感器数据结构体
 */
typedef struct
{
    uint8_t  online;             // 在线状态: 1=在线, 0=离线
    uint32_t last_update_time;   // 最后更新时间 (ms)
    uint16_t distance_mm;        // 距离值 (mm), 范围: 20~4500
    uint8_t  confidence;         // 置信度, 范围: 0~62, 值越大表示距离可信度越高
} tof_t;

extern tof_t tof_sensor;
extern uint8_t TOF_rx_buff[TOF_BUFF_SIZE];

/**
 * @brief 初始化TOF模块
 */
void TOF_Init(void);

/**
 * @brief 刷新TOF数据（需要在循环中调用）
 */
void TOF_Refresh(void);

/**
 * @brief 解析TOF ASCII帧数据
 * @param tof: TOF传感器结构体指针
 * @param buf: 接收缓冲区
 * @param len: 数据长度
 * @return 1=解析成功, 0=解析失败
 */
uint8_t tof_frame_parse(tof_t *tof, uint8_t *buf, uint16_t len);

#endif // __TOFSYS_H__