#ifndef __CAN_ENCODER_H__
#define __CAN_ENCODER_H__

#include "main.h"
#include "can_struct.h"
#include "can_api.h"

/**
 * @brief 编码器对象结构体
 */
typedef struct {
    can_msg_t rx_msg;       // 接收消息包（注册到底层链表，用于异步接收 ID=0x01 的回包）
    can_port_t port;        // 挂载的 CAN 端口（传入 CAN3_PORT）
    uint8_t addr;           // 编码器硬件物理地址（如 0x01）
    uint32_t raw_value;     // 12位原始位置计数值 (0 ~ 4095)
    float angle;            // 解算后的绝对角度值 (0.0 ~ 360.0 度)
    uint8_t last_cnt;       // 上一次收包计数器，用于判断是否有新数据到达
} Encoder_t;

void Encoder_Init(Encoder_t *encoder, uint8_t addr, can_port_t port);
void Encoder_SendReadCmd(Encoder_t *encoder);
void Encoder_Refresh(Encoder_t *encoder);

#endif /* __CAN_ENCODER_H__ */
