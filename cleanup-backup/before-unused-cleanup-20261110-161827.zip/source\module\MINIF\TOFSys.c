#include "TOFSys.h"
#include "usart.h"
#include "string.h"
#include "log.h"
#include "dwt_bsp.h"
#include <stdlib.h>
#include <stdio.h>

uart_rx_t TOF_msg;
uart_msg_t TOF_rx_msg;
tof_t tof_sensor;

uint8_t  TOF_rx_buff[TOF_BUFF_SIZE];
uint32_t TOF_Last_Count = 0;

char raw_str_buf[TOF_BUFF_SIZE + 1];
char raw_hex_buf[TOF_BUFF_SIZE * 3 + 1];

void TOF_Init(void)
{
    memset(TOF_rx_buff, 0, sizeof(TOF_rx_buff));
    memset(&TOF_msg,     0, sizeof(TOF_msg));
    memset(&TOF_rx_msg,  0, sizeof(TOF_rx_msg));
    memset(&tof_sensor,  0, sizeof(tof_sensor));

    TOF_rx_msg.huart   = &huart10;
    TOF_rx_msg.pBuffer = TOF_rx_buff;
    TOF_rx_msg.Len     = TOF_BUFF_SIZE;

    TOF_msg.rx_msg = &TOF_rx_msg;
    TOF_msg.count  = 0;

    tof_sensor.online = 0;
    tof_sensor.distance_mm = 0;
    tof_sensor.confidence = 0;
    tof_sensor.last_update_time = 0;

    uart_rx_init(&TOF_msg);
    
    // LOG_INFO("TOF Init Complete (No Frame Header Mode)");
}

/**
 * @brief TOF帧解析 - 适配无帧头的实际格式
 * @param tof: TOF传感器结构体指针
 * @param buf: 接收缓冲区
 * @param len: 数据长度
 * @return 1=解析成功, 0=解析失败
 * 
 * 实际数据格式（无帧头）：
 * "27, 59\n"      → 距离27mm, 置信度59
 * "327, 61\n"     → 距离327mm, 置信度61
 * "1234, 55\n"    → 距离1234mm, 置信度55
 * 
 * 格式：数字 + ", " + 数字 + "\n"
 */
uint8_t tof_frame_parse(tof_t *tof, uint8_t *buf, uint16_t len)
{
    if (len < 4)
    {
        return 0;
    }

    if (buf[len - 1] != 0x0A)
    {
        // LOG_ERROR("TOF frame tail error: 0x%02X (expected 0x0A)", buf[len - 1]);
        return 0;
    }

    char temp_str[TOF_BUFF_SIZE + 1];
    memcpy(temp_str, buf, len);
    temp_str[len] = '\0';

    char *separator_pos = strstr(temp_str, ", ");
    if (separator_pos == NULL)
    {
        // LOG_ERROR("TOF separator not found");
        return 0;
    }

    char distance_str[8] = {0};
    int distance_len = separator_pos - temp_str; 
    
    if (distance_len > 0 && distance_len < 8)
    {
        strncpy(distance_str, temp_str, distance_len);
        distance_str[distance_len] = '\0';
        tof->distance_mm = (uint16_t)atoi(distance_str);
    }
    else
    {
        // LOG_ERROR("TOF distance parse error (len=%d)", distance_len);
        return 0;
    }

    char confidence_str[4] = {0};
    char *confidence_start = separator_pos + 2;  
    int confidence_len = (temp_str + len - 1) - confidence_start;  
    
    if (confidence_len > 0 && confidence_len < 4)
    {
        strncpy(confidence_str, confidence_start, confidence_len);
        confidence_str[confidence_len] = '\0';
        tof->confidence = (uint8_t)atoi(confidence_str);
    }
    else
    {
        // LOG_ERROR("TOF confidence parse error (len=%d)", confidence_len);
        return 0;
    }

    return 1; 
}

void TOF_Refresh(void)
{
    uint32_t current_time = DWT_GetTimeline_ms();

    if (TOF_msg.count != TOF_Last_Count)
    {
        TOF_Last_Count = TOF_msg.count;
        uint16_t len = TOF_rx_msg.Len;

        memcpy(raw_str_buf, TOF_rx_buff, len);
        raw_str_buf[len] = '\0';

        uint16_t pos = 0;
        for (uint16_t i = 0; i < len; i++)
        {
            pos += snprintf(&raw_hex_buf[pos], sizeof(raw_hex_buf) - pos, "%02X ", TOF_rx_buff[i]);
        }
        raw_hex_buf[pos] = 0;

        // LOG_INFO("TOF[%d]: %s | HEX: %s", len, raw_str_buf, raw_hex_buf);

        if (tof_frame_parse(&tof_sensor, TOF_rx_buff, len))
        {
            tof_sensor.online = 1;
            tof_sensor.last_update_time = current_time;
            
            LOG_INFO("✓ TOF: %d mm, Conf=%d", tof_sensor.distance_mm, tof_sensor.confidence);
        }
    }
}