#include "can_struct.h"
#include "can_api.h"
#include "can_bsp.h"
// #include "MotorTool.h"
#include "list.h"

#include "string.h"
/**
************************************************************************
* @brief:      	can_bsp_init(void)
* @param:       void
* @retval:     	void
* @details:    	CAN 使能
************************************************************************
**/
void can_bsp_init(void)
{
	can_filter_init();
	HAL_FDCAN_Start(&hfdcan1); // 开启FDCAN
	HAL_FDCAN_Start(&hfdcan2);
	HAL_FDCAN_Start(&hfdcan3);
	HAL_FDCAN_ActivateNotification(&hfdcan1, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0);
	HAL_FDCAN_ActivateNotification(&hfdcan2, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0);
	HAL_FDCAN_ActivateNotification(&hfdcan3, FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0);
}
/**
************************************************************************
* @brief:      	can_filter_init(void)
* @param:       void
* @retval:     	void
* @details:    	CAN滤波器初始化
************************************************************************
**/
void can_filter_init(void)
{
	FDCAN_FilterTypeDef fdcan1_filter;

	fdcan1_filter.IdType = FDCAN_STANDARD_ID;			  // 标准ID
	fdcan1_filter.FilterIndex = 0;						  // 滤波器索引
	fdcan1_filter.FilterType = FDCAN_FILTER_RANGE;		  // 允许接收两个ID之间
	fdcan1_filter.FilterConfig = FDCAN_FILTER_TO_RXFIFO0; // 过滤器0关联到FIFO0
	fdcan1_filter.FilterID1 = 0x000;
	fdcan1_filter.FilterID2 = 0xFFF;
	HAL_FDCAN_ConfigFilter(&hfdcan1, &fdcan1_filter);
	HAL_FDCAN_ConfigGlobalFilter(&hfdcan1, FDCAN_REJECT, FDCAN_REJECT, FDCAN_FILTER_REMOTE, FDCAN_FILTER_REMOTE);
	HAL_FDCAN_ConfigFifoWatermark(&hfdcan1, FDCAN_CFG_RX_FIFO0, 1);

	FDCAN_FilterTypeDef fdcan2_filter;

	fdcan2_filter.IdType = FDCAN_STANDARD_ID;			  // 标准ID
	fdcan2_filter.FilterIndex = 14;						  // 滤波器索引
	fdcan2_filter.FilterType = FDCAN_FILTER_RANGE;		  // 允许接收两个ID之间
	fdcan2_filter.FilterConfig = FDCAN_FILTER_TO_RXFIFO0; // 过滤器0关联到FIFO0
	fdcan2_filter.FilterID1 = 0x000;
	fdcan2_filter.FilterID2 = 0xFFF;
	HAL_FDCAN_ConfigFilter(&hfdcan2, &fdcan2_filter);
	// HAL_FDCAN_ConfigGlobalFilter(&hfdcan2, FDCAN_REJECT, FDCAN_REJECT, FDCAN_FILTER_REMOTE, FDCAN_FILTER_REMOTE);
	HAL_FDCAN_ConfigFifoWatermark(&hfdcan2, FDCAN_CFG_RX_FIFO0, 1);

	FDCAN_FilterTypeDef fdcan3_filter;
	fdcan3_filter.IdType = FDCAN_STANDARD_ID;			  // 标准ID
	fdcan3_filter.FilterIndex = 18;						  // 滤波器索引
	fdcan3_filter.FilterType = FDCAN_FILTER_RANGE;		  // 允许接收两个ID之间
	fdcan3_filter.FilterConfig = FDCAN_FILTER_TO_RXFIFO0; // 过滤器0关联到FIFO0
	fdcan3_filter.FilterID1 = 0x000;
	fdcan3_filter.FilterID2 = 0xFFF;
	HAL_FDCAN_ConfigFilter(&hfdcan3, &fdcan3_filter);
	// HAL_FDCAN_ConfigGlobalFilter(&hfdcan3, FDCAN_REJECT, FDCAN_REJECT, FDCAN_FILTER_REMOTE, FDCAN_FILTER_REMOTE);
	HAL_FDCAN_ConfigFifoWatermark(&hfdcan3, FDCAN_CFG_RX_FIFO0, 1);
}
/**
************************************************************************
* @brief:      	fdcanx_send_data(FDCAN_HandleTypeDef *hfdcan, uint16_t id, uint8_t *data, uint32_t len)
* @param:       hfdcan：FDCAN句柄
* @param:       id：CAN设备ID
* @param:       data：发送的数据
* @param:       len：发送的数据长度 用Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_fdcan.h第967行的宏定义！！！
* @retval:     	void
* @details:    	发送数据
************************************************************************
**/
uint8_t fdcanx_send_data(FDCAN_HandleTypeDef *hfdcan, uint16_t id, uint8_t *data, uint32_t len)
{
	FDCAN_TxHeaderTypeDef TxHeader;

	TxHeader.Identifier = id;
	TxHeader.IdType = FDCAN_STANDARD_ID;			  // 标准ID
	TxHeader.TxFrameType = FDCAN_DATA_FRAME;		  // 数据帧
	TxHeader.DataLength = len;						  // 发送数据长度
	TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;  // 设置错误状态指示
	TxHeader.BitRateSwitch = FDCAN_BRS_OFF;			  // 不开启可变波特率
	TxHeader.FDFormat = FDCAN_CLASSIC_CAN;			  // 普通CAN格式
	TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS; // 用于发送事件FIFO控制, 不存储
	TxHeader.MessageMarker = 0x00;					  // 用于复制到TX EVENT FIFO的消息Maker来识别消息状态，范围0到0xFF

	if (HAL_FDCAN_AddMessageToTxFifoQ(hfdcan, &TxHeader, data) != HAL_OK)
		return 1; // 发送
	return 0;
}

/**
 * @brief :      	fdcanx_send_data_ext(FDCAN_HandleTypeDef *hfdcan, uint16_t id, uint8_t *data, uint32_t len)
 * 
 * @param hfdcan 	hfdcan：FDCAN句柄
 * @param id 		id：CAN设备ID
 * @param data 		data：发送的数据
 * @param len 		len：发送的数据长度 用Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_fdcan.h第967行的宏定义！！
 * @return uint8_t 
 * @details:    	发送数据
 */
uint8_t fdcanx_send_data_ext(FDCAN_HandleTypeDef *hfdcan, uint16_t id, uint8_t *data, uint32_t len)
{
	FDCAN_TxHeaderTypeDef TxHeader;

	TxHeader.Identifier = id;
	TxHeader.IdType = FDCAN_EXTENDED_ID;			  // 扩展ID
	TxHeader.TxFrameType = FDCAN_DATA_FRAME;		  // 数据帧
	TxHeader.DataLength = len;						  // 发送数据长度
	TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;  // 设置错误状态指示
	TxHeader.BitRateSwitch = FDCAN_BRS_OFF;			  // 不开启可变波特率
	TxHeader.FDFormat = FDCAN_CLASSIC_CAN;			  // 普通CAN格式
	TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS; // 用于发送事件FIFO控制, 不存储
	TxHeader.MessageMarker = 0x00;					  // 用于复制到TX EVENT FIFO的消息Maker来识别消息状态，范围0到0xFF

	if (HAL_FDCAN_AddMessageToTxFifoQ(hfdcan, &TxHeader, data) != HAL_OK)
		return 1; // 发送
	return 0;
}

uint8_t fdcanx_send_data_fd(FDCAN_HandleTypeDef *hfdcan, uint16_t id, uint8_t *data, uint32_t len)
{
	FDCAN_TxHeaderTypeDef TxHeader;

	TxHeader.Identifier = id;
	TxHeader.IdType = FDCAN_STANDARD_ID;			  // 标准ID
	TxHeader.TxFrameType = FDCAN_DATA_FRAME;		  // 数据帧
	TxHeader.DataLength = len;						  // 发送数据长度
	TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;  // 设置错误状态指示
	TxHeader.BitRateSwitch = FDCAN_BRS_ON;			  // 不开启可变波特率
	TxHeader.FDFormat = FDCAN_FD_CAN;				  // 扩展CAN格式
	TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS; // 用于发送事件FIFO控制, 不存储
	TxHeader.MessageMarker = 0x00;					  // 用于复制到TX EVENT FIFO的消息Maker来识别消息状态，范围0到0xFF

	if (HAL_FDCAN_AddMessageToTxFifoQ(hfdcan, &TxHeader, data) != HAL_OK)
		return 1; // 发送
	return 0;
}

/**
************************************************************************
* @brief:      	fdcanx_receive(FDCAN_HandleTypeDef *hfdcan, uint8_t *buf)
* @param:       hfdcan：FDCAN句柄
* @param:       buf：接收数据缓存
* @retval:     	接收的数据长度
* @details:    	接收数据
************************************************************************
**/
FDCAN_RxHeaderTypeDef fdcan_RxHeader;
FDCAN_RxHeaderTypeDef *fdcanx_receive(FDCAN_HandleTypeDef *hfdcan, uint8_t *buf)
{

	if (HAL_FDCAN_GetRxMessage(hfdcan, FDCAN_RX_FIFO0, &fdcan_RxHeader, buf) != HAL_OK)
		return NULL; // 接收失败数据
	return &fdcan_RxHeader;
}
/**
************************************************************************
* @brief:      	HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
* @param:       hfdcan；FDCAN句柄
* @param:       RxFifo0ITs：中断标志位
* @retval:     	void
* @details:    	HAL库的FDCAN中断回调函数
************************************************************************
**/
void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
	if ((RxFifo0ITs & FDCAN_IT_RX_FIFO0_NEW_MESSAGE) != RESET)
	{
		if (hfdcan == &hfdcan1)
		{
			fdcan1_rx_callback();
		}
		if (hfdcan == &hfdcan2)
		{
			fdcan2_rx_callback();
		}
		if (hfdcan == &hfdcan3)
		{
			fdcan3_rx_callback();
		}
	}
}
/**
************************************************************************
* @brief:      	fdcan_rx_callback(void)
* @param:       void
* @retval:     	void
* @details:    	供用户调用的接收弱函数
************************************************************************
**/
uint8_t rx_data1[8] = {0};
void fdcan1_rx_callback(void)
{
	if (fdcanx_receive(&hfdcan1, rx_data1) == NULL)
		return;

	can_msg_t *msg = can_msg_find_item(&can1_rx_msg_list, fdcan_RxHeader.Identifier);
	if (msg == NULL)
		return;

	memcpy(msg->data, rx_data1, fdcan_RxHeader.DataLength);
	msg->len = fdcan_RxHeader.DataLength;
	msg->cnt++;
}
uint8_t rx_data2[8] = {0};
void fdcan2_rx_callback(void)
{
	if (fdcanx_receive(&hfdcan2, rx_data2) == NULL)
		return;

	can_msg_t *msg = can_msg_find_item(&can2_rx_msg_list, fdcan_RxHeader.Identifier);
	if (msg == NULL)
		return;
	memcpy(msg->data, rx_data2, fdcan_RxHeader.DataLength);
	msg->len = fdcan_RxHeader.DataLength;
	msg->cnt++;
}
uint8_t rx_data3[8] = {0};
void fdcan3_rx_callback(void)
{
	if (fdcanx_receive(&hfdcan3, rx_data3) == NULL)
		return;

	can_msg_t *msg = can_msg_find_item(&can3_rx_msg_list, fdcan_RxHeader.Identifier);
	if (msg == NULL)
		return;
	memcpy(msg->data, rx_data3, fdcan_RxHeader.DataLength);
	msg->len = fdcan_RxHeader.DataLength;
	msg->cnt++;
}
