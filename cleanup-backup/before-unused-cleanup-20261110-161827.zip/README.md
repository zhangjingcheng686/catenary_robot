# 接触网三机械臂巡检机器人开发库

本系统采用三机械臂协同作业方式，实现对铁路接触网设备的全方位智能巡检。系统集成了机器视觉、多轴运动控制、实时通信等功能模块，可自动完成接触网设备的缺陷检测、状态监测和数据采集工作。

更多代码内容参看[代码文档(html)](doc/html/index.html)

## 模块文档

### BSP层 (硬件抽象层)

- [蜂鸣器部分](source/bsp/buzzer/buzzer_bsp.md)
- [CAN通讯部分](source/bsp/can/can_api.md)
- [DWT部分](source/bsp/dwt/dwt_bsp.md)
- [UART通讯部分](source/bsp/uart/uart_api.md)
- [BMI088 IMU部分](source/bsp/BMI088/BMI088.md)
- [CRC模块](source/bsp/crc/CRC模块说明.md)

### 模块层


#### 控制模块
- [控制系统](source/module/control/control_module.md)
- [电源控制](source/module/control/PowerControl/PowerControl.md)

#### 其他模块
- [IMU模块](source/module/IMU/IMU_module.md)
- [大疆电机控制](source/module/motor/motor_Dji/motor_DJI.md)
- [达妙电机控制](source/module/motor/motor_DM/motor_DM.md)
- [滤波器](source/module/filter/filter_module.md)
- [激光测距模块](source/module/MINIF)
## 有关代码规范

见[代码规范](code_style.md)

## 系统特点

三臂协同：三个机械臂可独立工作或协同配合，提高作业效率
智能检测：集成深度学习算法，实现接触网设备缺陷的自动识别
精确定位：多传感器融合，确保机械臂精确到达检测位置
实时通信：支持远程监控和数据实时传输
安全可靠：多重安全保护机制，确保设备和人员安全

## 快速开始
详细的安装和使用说明请参见用户手册