#include "can_encoder.h"
#include "fdcan.h"
#include "string.h"

/**
 * @brief  初始化编码器对象并注册到系统 CAN 接收链表中
 * @param  encoder : 编码器句柄指针
 * @param  addr    : 编码器的硬件物理地址 (如 0x01)
 * @param  port    : 使用的 CAN 端口号 (如 CAN3_PORT)
 */
void Encoder_Init(Encoder_t *encoder, uint8_t addr, can_port_t port)
{
    encoder->addr = addr;
    encoder->port = port;
    encoder->raw_value = 0;
    encoder->angle = 0.0f;
    encoder->last_cnt = 0;

    encoder->rx_msg.port = port;
    encoder->rx_msg.id = addr; 
    encoder->rx_msg.len = 7;     
    encoder->rx_msg.cnt = 0;
    memset(encoder->rx_msg.data, 0, 8);

    can_msg_add_item(&encoder->rx_msg);
}

/**
 * @brief  向总线发送读取当前编码器数值的经典 CAN 帧
 */
void Encoder_SendReadCmd(Encoder_t *encoder)
{
    can_msg_t tx_msg;
    tx_msg.port = encoder->port;         
    tx_msg.id = encoder->addr;      // 让发送帧的 ID 直接等于编码器地址
    
    tx_msg.data[0] = 0x04;          // 数据域长度
    tx_msg.data[1] = encoder->addr; // 目标编码器物理地址
    tx_msg.data[2] = 0x01;          // 读数值指令码
    tx_msg.data[3] = 0x00;          // 占位符
    
    tx_msg.len = FDCAN_DLC_BYTES_4; 

    can_msg_send_classical(&tx_msg);
}

/**
 * @brief  解析并刷新编码器当前的角度值 (已映射 -180~180 且方向已与电机对齐)
 */
void Encoder_Refresh(Encoder_t *encoder)
{
    if (encoder->rx_msg.cnt != encoder->last_cnt)
    {
        if (encoder->rx_msg.data[1] == encoder->addr && encoder->rx_msg.data[2] == 0x01)
        {
            uint32_t raw = encoder->rx_msg.data[3] |
                           (encoder->rx_msg.data[4] << 8) |
                           (encoder->rx_msg.data[5] << 16) |
                           (encoder->rx_msg.data[6] << 24);

            encoder->raw_value = raw;

            // 1. 先计算出 0 ~ 360 的原始角度
            float calc_angle = (float)(raw % 4096) * 360.0f / 4096.0f;
            
            // 2. 将角度强制映射到 -180 ~ 180 之间
            if (calc_angle > 180.0f) {
                calc_angle -= 360.0f;
            }
            
            // 3. 【核心修改】：在这里直接取反，彻底消除物理反向安装的差异！
            calc_angle = -calc_angle; 

            // 4. 赋值给结构体，此时的 angle 已经是完美对齐的数据了
            encoder->angle = calc_angle;
        }
        encoder->last_cnt = encoder->rx_msg.cnt;
    }
}